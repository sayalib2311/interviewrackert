package com.eval.interviewtracker.controller;

import org.springframework.http.ResponseEntity;

import com.eval.interviewtracker.dto.UserDetailsDTO;
import com.eval.interviewtracker.exception.ValidationException;

public interface IUserController {
	
	public ResponseEntity<?> addUser(UserDetailsDTO userDetails) throws ValidationException;

	public ResponseEntity<?> deleteUser(int id) throws ValidationException;

	public ResponseEntity<?> getUserList();

	public ResponseEntity<?> findUsersByInterviewId(int interviewId) throws ValidationException;

}
