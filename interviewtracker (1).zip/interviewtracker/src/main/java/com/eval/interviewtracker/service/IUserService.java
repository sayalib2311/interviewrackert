package com.eval.interviewtracker.service;

import java.util.List;

import com.eval.interviewtracker.dto.UserDetailsDTO;
import com.eval.interviewtracker.model.UserDetails;

public interface IUserService {

	public void saveUser(UserDetailsDTO userDetailsdto);

	public void deleteUser(int id);

	
	public List<UserDetailsDTO> returnUserList();
	
	public List<UserDetails> returnUserDetails(int interviewId);
	
	

}
