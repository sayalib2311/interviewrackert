package com.eval.interviewtracker.exception;

public class ValidationException extends Exception {
	
	public ValidationException(String errorMessage) {
		super(errorMessage);
	}
}
