package com.eval.interviewtracker.service;

import java.util.List;

import com.eval.interviewtracker.dto.InterviewDetailsDTO;
import com.eval.interviewtracker.exception.ValidationException;
import com.eval.interviewtracker.model.InterviewDetails;

public interface IInterviewService {

	public void saveInterview(InterviewDetailsDTO interviewDetailsdto);

	public void deleteInterview(int id) throws ValidationException ;

	public String updateInterviewStatus(int id, String status);
	
	public List<InterviewDetailsDTO> returnInterviewList();
	
	public long returnInterviewCount();
	
	public InterviewDetails returnInterviewDetails(String interviewName, String interviewerName);
}
