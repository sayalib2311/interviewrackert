package com.eval.interviewtracker.service;

import java.util.List;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eval.interviewtracker.dto.UserDetailsDTO;
import com.eval.interviewtracker.mapper.UserDetailsMapper;
import com.eval.interviewtracker.model.InterviewDetails;
import com.eval.interviewtracker.model.UserDetails;
import com.eval.interviewtracker.repository.IUserDetailsRepository;

@Service
public class UserServiceImpl  implements IUserService{
	
	@Autowired
	private IUserDetailsRepository userRepository;
	
	public void saveUser(UserDetailsDTO userDetailsDTO) {
		userRepository.save(UserDetailsMapper.mapUserDetails(userDetailsDTO));
	}

	@Override
	public void deleteUser(int id) {
		userRepository.deleteById(id);
	}
	
	@ManyToOne
    @JoinColumn(name="interviewId", nullable=false)
	@Override
	public List<UserDetailsDTO> returnUserList() {
		return UserDetailsMapper.mapUserDetailsDtoList(userRepository.findAll());

	}
	
	@Override
	public List<UserDetails> returnUserDetails(int interviewId) {

		return userRepository.findUsersByInterviewId(interviewId);
	}

	
	

}
