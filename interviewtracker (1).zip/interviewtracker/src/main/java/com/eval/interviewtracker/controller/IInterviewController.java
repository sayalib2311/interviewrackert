package com.eval.interviewtracker.controller;

import org.springframework.http.ResponseEntity;

import com.eval.interviewtracker.dto.InterviewDetailsDTO;
import com.eval.interviewtracker.exception.ValidationException;

public interface IInterviewController {

	public ResponseEntity<?> addInterview(InterviewDetailsDTO interviewDetails) throws ValidationException;

	public ResponseEntity<?> deleteInterview(int id) throws ValidationException;

	public ResponseEntity<?> updateInterviewStatus(int id, String interviewStatus) throws ValidationException;

	public ResponseEntity<?> getInterviewList();

	public ResponseEntity<?> getInterviewCount();

	public ResponseEntity<?> findByInterviewNameAndInterviewerDetails(String interviewName, String interviewerName)
			throws ValidationException;
}
