package com.eval.interviewtracker.mapper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.eval.interviewtracker.dto.InterviewDetailsDTO;
import com.eval.interviewtracker.model.InterviewDetails;

public class InterviewDetailsMapper {

	public static InterviewDetails mapInterviewDetails(InterviewDetailsDTO interviewDetailsdto) {

		InterviewDetails interviewDao = new InterviewDetails();
		interviewDao.setInterviewId(interviewDetailsdto.getInterviewId());
		interviewDao.setDate(interviewDetailsdto.getDate());
		interviewDao.setTime(interviewDetailsdto.getTime());
		interviewDao.setInterviewerName(interviewDetailsdto.getInterviewerName());
		interviewDao.setInterviewName(interviewDetailsdto.getInterviewName());
		interviewDao.setInterviewStatus(interviewDetailsdto.getInterviewStatus());
		interviewDao.setRemarks(interviewDetailsdto.getRemarks());
		interviewDao.setUsersSkills(interviewDetailsdto.getUsersSkills());
		return interviewDao;
	}

	public static List<InterviewDetailsDTO> mapInterviewDetailsDtoList(Iterable<InterviewDetails> iterable) {

		List<InterviewDetailsDTO> interviewDTOList = new ArrayList<InterviewDetailsDTO>();
		Iterator<InterviewDetails> it = iterable.iterator();
		while (it.hasNext()) {
			InterviewDetailsDTO interviewDto = new InterviewDetailsDTO();
			InterviewDetails interview = it.next();
			interviewDto.setInterviewId(interview.getInterviewId());
			interviewDto.setDate(interview.getDate());
			interviewDto.setTime(interview.getTime());
			interviewDto.setInterviewerName(interview.getInterviewerName());
			interviewDto.setInterviewName(interview.getInterviewName());
			interviewDto.setInterviewStatus(interview.getInterviewStatus());
			interviewDto.setRemarks(interview.getRemarks());
			interviewDto.setUsersSkills(interview.getUsersSkills());
			interviewDTOList.add(interviewDto);
		}
		return interviewDTOList;
	}
}
